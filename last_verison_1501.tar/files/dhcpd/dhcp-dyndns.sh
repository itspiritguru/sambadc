#!/bin/bash

# /etc/dhcp/bin/dhcp-dyndns.sh

# Скрипт для обновления DDNS в режиме secure на Samba 4
# Версия: 0.8.8

# DNS domain
domain=$(hostname -d)
if [ -z ${domain} ]; then
    echo "Невозможно определить имя домена, DNS настроен правильно?"
    echo "Невозможно продолжить... Выход."
    logger "Cannot obtain domain name, is DNS set up correctly?"
    logger "Cannot continue... Exiting."
    exit 1
fi

# Samba 4 realm
REALM=$(echo ${domain^^})

# Дополнительный флаг nsupdate (-g уже установлен), т.е. "-d" для отладки
#NSUPDFLAGS="-d"

# krbcc ticket cache
export KRB5CCNAME="/tmp/dhcp-dyndns.cc"

# Kerberos principal
SETPRINCIPAL="dhcpduser@${REALM}"
# Kerberos keytab
# /etc/dhcp/dhcpduser.keytab
# krbcc ticket cache
# /tmp/dhcp-dyndns.cc

TESTUSER=$(/usr/local/samba/bin/wbinfo -u | grep dhcpduser)
if [ -z "${TESTUSER}" ]; then
    echo "Нет пользователя AD dhcp , требуется сначало его создать... Выход."
    echo "Вы должны выполнить следующие команды"
    echo "kinit Administrator@${REALM}"
    echo "samba-tool user create dhcpduser --random-password --description=\"Непривелигерованный пользователь для обновления DNS через DHCP сервер\""
    echo "samba-tool user setexpiry dhcpduser --noexpiry"
    echo "samba-tool group addmembers DnsAdmins dhcpduser"
    exit 1
fi

# Check for Kerberos keytab
if [ ! -f /etc/dhcp/dhcpduser.keytab ]; then
    echo "Требуемый файл /etc/dhcpduser.keytab не найден, его необходимо создать."
    echo "Выполните следующие команды от пользователя root"
    echo "samba-tool domain exportkeytab --principal=${SETPRINCIPAL} /etc/dhcp/dhcpduser.keytab"
    echo "chown XXXX:XXXX /etc/dhcp/dhcpduser.keytab"
    echo "Замените 'XXXX:XXXX' на пользователя и группу, от имени которого выполняется сервер DHCP"
    echo "chmod 400 /etc/dhcp/dhcpduser.keytab"
    exit 1
fi

# Переменные, предоставленные dhcpd.conf
action=$1
ip=$2
DHCID=$3
name=${4%%.*}

usage()
{
echo "USAGE:"
echo "  `basename $0` add ip-address dhcid|mac-address hostname"
echo "  `basename $0` delete ip-address dhcid|mac-address"
}

_KERBEROS () {
# берем текущее время в цифровом формате
test=$(date +%d'-'%m'-'%y' '%H':'%M':'%S)
# Примечание: были проблемы с этим
# проверьте, что 'date' возвращает что-то вроде
# 04-10-17 10:23:15

# Check for valid kerberos ticket
#logger "${test} [dyndns] : Running check for valid kerberos ticket"
klist -c /tmp/dhcp-dyndns.cc -s
if [ "$?" != "0" ]; then
    logger "${test} [dyndns] : Getting new ticket, old one has expired"
    kinit -F -k -t /etc/dhcp/dhcpduser.keytab -c /tmp/dhcp-dyndns.cc "${SETPRINCIPAL}"
    if [ "$?" != "0" ]; then
        logger "${test} [dyndns] : dhcpd kinit for dynamic DNS failed"
        exit 1;
    fi
fi

}

# Выход, если нет ip адреса или mac-адреса
if [ -z "${ip}" ] || [ -z "${DHCID}" ]; then
    usage
    exit 1
fi

# Выйдите, если не указано имя компьютера, и если действие не является 'delete'
if [ "${name}" = "" ]; then
    if [ "${action}" = "delete" ]; then
        name=$(host -t PTR "${ip}" | awk '{print $NF}' | awk -F '.' '{print $1}')
    else
        usage
        exit 1;
    fi
fi

# Установить PTR адрес
ptr=$(echo ${ip} | awk -F '.' '{print $4"."$3"."$2"."$1".in-addr.arpa"}')

## nsupdate ##

case "${action}" in
add)
    _KERBEROS

nsupdate -g ${NSUPDFLAGS} < UPDATE
server 127.0.0.1
realm ${REALM}
update delete ${name}.${domain} 3600 A
update add ${name}.${domain} 3600 A ${ip}
send
UPDATE
result1=$?

nsupdate -g ${NSUPDFLAGS}  UPDATE
server 127.0.0.1
realm ${REALM}
update delete ${ptr} 3600 PTR
update add ${ptr} 3600 PTR ${name}.${domain}
send
UPDATE
result2=$?
;;
delete)
     _KERBEROS

nupdate -g ${NSUPDFLAGS}  UPDATE
server 127.0.0.1
realm ${REALM}
update delete ${name}.${domain} 3600 A
send
UPDATE
result1=$?
nsupdate -g ${NSUPDFLAGS}  UPDATE
server 127.0.0.1
realm ${REALM}
update delete ${ptr}3600 PTR
send
UPDATE
result2=$?
;;
*)
echo "Invalid action speciied"
exit 103
;;
esac

result="${result1}${result2}"

if [ "${result}" != "00" ]; then
    logger "DHCP-DNS Update failed: ${result}"
else
    logger "DHCP-DNS Update succeeded"
fi

exit ${result}

