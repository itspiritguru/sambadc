#!/bin/bash

set -euo pipefail

sed -i 's/INTERFACESv4=""/INTERFACESv4="eth0"/g' /etc/default/isc-dhcp-server
if [ ! -f /data/dhcpd.leases ]; then
  touch /data/dhcpd.leases
fi
#exec /usr/sbin/dhcpd -4 -f -cf /data/dhcpd.conf -lf /data/dhcpd.leases --no-pid
